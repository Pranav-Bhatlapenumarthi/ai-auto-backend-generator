javascript
const dbConfig = {
  development: {
    username: 'root',
    password: 'password',
    database: 'database',
    host: 'localhost',
    dialect: 'mysql'
  },
  test: {
    username: 'root',
    password: 'password',
    database: 'database',
    host: 'localhost',
    dialect: 'mysql'
  },
  production: {
    username: 'root',
    password: 'password',
    database: 'database',
    host: 'localhost',
    dialect: 'mysql'
  }
};

module.exports = dbConfig;